// src/insertionsort.h
#pragma once
#include <vector>

// 实现泛型的插入排序
template <typename T>
void insertionSort(std::vector<T> &A){
    size_t n = A.size();
    for(size_t j=1;j<n;j++){
        T key = A[j];
        // 把A[j]插入到已经完成排序的A[1 .. j-1]中
        int i = j-1;
        while(i>=0 && A[i]>key){
            A[i+1] = A[i]; // 把A[j-1]及以前的依次后移，直到找到该插入的位置为止。如果到了i=0还插不上，就说明应该插在第一位
            i = i-1;
        }
        A[i+1] = key;
    }
}

// 课件里的伪代码的下标是从1开始的。所以在自己写的时候，各种地方都要相应地-1